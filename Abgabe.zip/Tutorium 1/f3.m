function Z = f3(X,Y)
Z = abs( (1+1./(X)).^X - (1+1./(Y)).^Y);
end