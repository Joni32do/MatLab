function Z = f5(X,Y)
Z = sin(X).*Y;
end