function [Z] = f1(X,Y)
% An easy but quite beautiful example function
Z = sin(X).*cos(Y);
end

